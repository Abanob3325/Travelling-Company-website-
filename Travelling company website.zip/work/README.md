# موقع شركة الأمانة

موقع احترافي لشركة الأمانة لإلحاق العمالة المصرية بالخارج.

## 🚀 طرق رفع الموقع

### 1. Google Sites (الأسهل)
1. اذهب إلى [sites.google.com](https://sites.google.com)
2. سجل دخول بحس جوجل
3. اضغط "إنشاء موقع جديد"
4. اختر "إنشاء موقع فارغ"
5. ارفع ملفات المشروع (index.html, styles.css, script.js)
6. احصل على رابط مثل: `sites.google.com/view/your-site`

### 2. GitHub Pages (مجاني ومهني)
1. أنشئ حساب على [GitHub](https://github.com)
2. أنشئ repository جديد
3. ارفع ملفات المشروع
4. اذهب إلى Settings > Pages
5. اختر Source: Deploy from a branch
6. اختر branch: main
7. احصل على رابط مثل: `username.github.io/repository-name`

### 3. Netlify (مجاني وسريع)
1. اذهب إلى [netlify.com](https://netlify.com)
2. سجل حساب جديد
3. اسحب ملفات المشروع إلى منطقة الرفع
4. احصل على رابط فوري

### 4. Vercel (مجاني ومتقدم)
1. اذهب إلى [vercel.com](https://vercel.com)
2. سجل حساب جديد
3. اربط حساب GitHub
4. اختر repository
5. احصل على رابط فوري

## 📁 ملفات المشروع
- `index.html` - الصفحة الرئيسية
- `styles.css` - التصميم
- `script.js` - الوظائف التفاعلية
- `README.md` - هذا الملف

## 🎨 الميزات
- تصميم متجاوب
- دعم اللغة العربية (RTL)
- خريطة جوجل مابس
- روابط وسائل التواصل الاجتماعي
- أقسام تفاعلية
- انتقال سلس بين الصفحات

## 🔧 التخصيص
يمكنك تعديل:
- الألوان في `styles.css`
- المحتوى في `index.html`
- الوظائف في `script.js`

## 📞 معلومات التواصل
- الهاتف: 0227948692 / 01001497437
- البريد الإلكتروني: alwyal_amanaa@yahoo.com
- الفيسبوك: [رابط الفيسبوك](https://www.facebook.com/share/g/167q6UEz3H/?mibextid=wwXIfr)
- لينكد إن: [رابط لينكد إن](https://www.linkedin.com/in/%D8%B4%D8%B1%D9%83%D8%A9-%D8%A7%D9%84%D8%A7%D9%85%D8%A7%D9%86%D8%A9-%D9%84%D9%84%D8%AA%D9%88%D8%B8%D9%8A%D9%81-%D8%A8%D8%A7%D9%84%D8%AE%D8%A7%D8%B1%D8%AC-154301240)

## 📍 العنوان
٦ شارع الديوان - جاردن سيتي - خلف دار الحكمة - القصر العيني

---
© 2025 شركة الأمانة. جميع الحقوق محفوظة. 