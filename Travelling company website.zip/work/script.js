// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(n => n.addEventListener('click', () => {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
}));

// Services Section Toggle
document.addEventListener('DOMContentLoaded', () => {
    const servicesLink = document.querySelector('a[href="#services"]');
    const servicesSection = document.getElementById('services');
    const allSections = document.querySelectorAll('section[id]');
    
    if (servicesLink && servicesSection) {
        servicesLink.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Hide all other sections
            allSections.forEach(section => {
                if (section.id !== 'services') {
                    section.style.display = 'none';
                }
            });
            
            // Show services section
            servicesSection.style.display = 'block';
            servicesSection.scrollIntoView({ behavior: 'smooth' });
        });
    }
    
    // Add click handlers for other navigation links to show their sections
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection && targetId !== 'services') {
                e.preventDefault();
                
                // Hide services section
                if (servicesSection) {
                    servicesSection.style.display = 'none';
                }
                
                // Show target section
                allSections.forEach(section => {
                    if (section.id === targetId) {
                        section.style.display = 'block';
                    } else if (section.id !== 'services') {
                        section.style.display = 'block';
                    }
                });
                
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // More Button Functionality
    const moreBtn = document.getElementById('moreBtn');
    const visionSection = document.getElementById('vision');
    const valuesSection = document.getElementById('values');
    const capabilitiesSection = document.getElementById('capabilities');
    const goalsSection = document.getElementById('goals');
    
    if (moreBtn) {
        let sectionsVisible = false; // Track if sections are visible
        
        moreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            
            if (!sectionsVisible) {
                // Show additional sections
                if (visionSection) visionSection.style.display = 'block';
                if (valuesSection) valuesSection.style.display = 'block';
                if (capabilitiesSection) capabilitiesSection.style.display = 'block';
                if (goalsSection) goalsSection.style.display = 'block';
                
                // Scroll to vision section
                if (visionSection) {
                    visionSection.scrollIntoView({ behavior: 'smooth' });
                }
                
                // Change button text
                moreBtn.textContent = 'إخفاء';
                moreBtn.style.opacity = '1';
                moreBtn.style.pointerEvents = 'auto';
                
                sectionsVisible = true;
            } else {
                // Hide additional sections
                if (visionSection) visionSection.style.display = 'none';
                if (valuesSection) valuesSection.style.display = 'none';
                if (capabilitiesSection) capabilitiesSection.style.display = 'none';
                if (goalsSection) goalsSection.style.display = 'none';
                
                // Scroll back to about section
                const aboutSection = document.getElementById('about');
                if (aboutSection) {
                    aboutSection.scrollIntoView({ behavior: 'smooth' });
                }
                
                // Change button text back
                moreBtn.textContent = 'المزيد';
                moreBtn.style.opacity = '1';
                moreBtn.style.pointerEvents = 'auto';
                
                sectionsVisible = false;
            }
        });
    }
    
    // Footer Navigation Links
    const footerLinks = document.querySelectorAll('.footer a[href^="#"]');
    footerLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                // Show all sections first
                const allSections = document.querySelectorAll('section[id]');
                allSections.forEach(section => {
                    if (section.id !== 'services') {
                        section.style.display = 'block';
                    }
                });
                
                // Hide services section if not the target
                if (targetId !== 'services' && servicesSection) {
                    servicesSection.style.display = 'none';
                }
                
                // Show services section if it's the target
                if (targetId === 'services' && servicesSection) {
                    servicesSection.style.display = 'block';
                    // Hide other sections when showing services
                    allSections.forEach(section => {
                        if (section.id !== 'services') {
                            section.style.display = 'none';
                        }
                    });
                }
                
                // Scroll to target section
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Logo/Company Name Home Navigation
    const logoLink = document.querySelector('.nav-logo a');
    if (logoLink) {
        logoLink.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Show all sections except services
            const allSections = document.querySelectorAll('section[id]');
            allSections.forEach(section => {
                if (section.id !== 'services') {
                    section.style.display = 'block';
                }
            });
            
            // Hide services section
            if (servicesSection) {
                servicesSection.style.display = 'none';
            }
            
            // Reset more button if it was clicked
            if (moreBtn) {
                moreBtn.textContent = 'المزيد';
                moreBtn.style.opacity = '1';
                moreBtn.style.pointerEvents = 'auto';
                // Reset the sections visibility state
                if (typeof sectionsVisible !== 'undefined') {
                    sectionsVisible = false;
                }
            }
            
            // Scroll to top of page
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Navbar background change on scroll
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = 'none';
    }
});

// Contact Form Handling
const contactForm = document.getElementById('contactForm');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const name = formData.get('name');
        const email = formData.get('email');
        const phone = formData.get('phone');
        const service = formData.get('service');
        const message = formData.get('message');
        
        // Basic validation
        if (!name || !email || !service || !message) {
            showMessage('Please fill in all required fields.', 'error');
            return;
        }
        
        if (!isValidEmail(email)) {
            showMessage('Please enter a valid email address.', 'error');
            return;
        }
        
        // Simulate form submission (in a real scenario, this would send to a server)
        showMessage('Thank you for your message! We will get back to you soon.', 'success');
        
        // Reset form
        this.reset();
        
        // Scroll to show the message
        setTimeout(() => {
            document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
        }, 100);
    });
}

// Email validation function
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Show success/error messages
function showMessage(message, type) {
    // Remove existing messages
    const existingMessage = document.querySelector('.success-message, .error-message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // Create new message
    const messageDiv = document.createElement('div');
    messageDiv.className = `${type}-message`;
    messageDiv.textContent = message;
    
    // Insert before the form
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.parentNode.insertBefore(messageDiv, contactForm);
        
        // Remove message after 5 seconds
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.service-card, .contact-item, .stat');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Counter animation for stats
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start);
        }
    }, 16);
}

// Animate stats when they come into view
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const statNumber = entry.target.querySelector('h3');
            const text = statNumber.textContent;
            const number = parseInt(text.replace(/[^0-9]/g, ''));
            
            if (text.includes('+')) {
                animateCounter(statNumber, number);
                statNumber.textContent = number + '+';
            } else if (text.includes('%')) {
                animateCounter(statNumber, number);
                statNumber.textContent = number + '%';
            } else {
                animateCounter(statNumber, number);
            }
            
            statsObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

// Observe stats for counter animation
document.addEventListener('DOMContentLoaded', () => {
    const stats = document.querySelectorAll('.stat');
    stats.forEach(stat => {
        statsObserver.observe(stat);
    });
});

// Add loading animation to service cards
document.addEventListener('DOMContentLoaded', () => {
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
});

// Parallax effect for hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    const rate = scrolled * -0.5;
    hero.style.transform = `translateY(${rate}px)`;
});

// Add hover effects to service cards
document.addEventListener('DOMContentLoaded', () => {
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0) scale(1)';
        });
    });
});

// Form field focus effects
document.addEventListener('DOMContentLoaded', () => {
    const formFields = document.querySelectorAll('.form-group input, .form-group select, .form-group textarea');
    formFields.forEach(field => {
        field.addEventListener('focus', () => {
            field.parentElement.style.transform = 'scale(1.02)';
        });
        
        field.addEventListener('blur', () => {
            field.parentElement.style.transform = 'scale(1)';
        });
    });
});

// Add typing effect to hero title
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// Initialize typing effect when page loads
document.addEventListener('DOMContentLoaded', () => {
    const heroTitle = document.querySelector('.hero-content h1');
    if (heroTitle) {
        const originalText = heroTitle.textContent;
        setTimeout(() => {
            typeWriter(heroTitle, originalText, 50);
        }, 500);
    }
});

// Add scroll progress indicator
function createScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 3px;
        background: linear-gradient(90deg, #2563eb, #3b82f6);
        z-index: 1001;
        transition: width 0.1s ease;
    `;
    document.body.appendChild(progressBar);
    
    window.addEventListener('scroll', () => {
        const scrollTop = document.documentElement.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrollPercent = (scrollTop / scrollHeight) * 100;
        progressBar.style.width = scrollPercent + '%';
    });
}

// Initialize scroll progress
document.addEventListener('DOMContentLoaded', createScrollProgress); 